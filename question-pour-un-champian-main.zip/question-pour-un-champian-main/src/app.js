const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const express = require('express');
const path = require('path');
const dotenv = require('dotenv');
dotenv.config();

//hosting site
const dbHost = process.env.DB_HOST;
const dbUsername = process.env.DB_USERNAME;
const dbPassword = process.env.DB_PASSWORD;
const dbName = process.env.DB_DBNAME;

const databaseUrl = `mysql://${dbUsername}:${dbPassword}@${dbHost}:3306/${dbName}?schema=public`;

process.env.DATABASE_URL = databaseUrl;
//end

const app = express();
const port = process.env.PORT || 3000;

const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const questionRoutes = require('./routes/questionRoutes');
const gameSessionRoutes = require('./routes/gameSessionRoutes');
const participantResponseRoutes = require('./routes/participantResponseRoutes');
const noticesRoutes = require('./routes/noticesRoutes');
const questiontest = require('./routes/questiontestRoute');
const { swaggerUi, specs } = require('./utils/swagger');
const errorHandler = require('./middlewares/errorHandler');

const cookieParser = require('cookie-parser');
app.use(cookieParser());

// Configurer express pour gérer les données POST au format JSON
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Servir les fichiers statiques (HTML, CSS, JS)
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.use('/auth', authRoutes);
app.use('/users', userRoutes);
app.use('/questions', questionRoutes);
app.use('/gamesessions', gameSessionRoutes);
app.use('/responses', participantResponseRoutes);
app.use('/notices', noticesRoutes);
app.use('/questiontest', questiontest);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(specs));

// Set the view engine to ejs
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'public'));


app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'Home.html'));
});

// Route pour servir la page de connexion
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'Login.html'));
});

// Route pour servir la page de connexion
app.get('/register', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'register.html'));
});

app.get('/reset-password', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'reset-password.html'));
});



app.get('/dashboard/', async (req, res) => {

  try {
    // Fetch the top 4 players ordered by score descending
    const topPlayers = await prisma.user.findMany({
      where: { role: "PARTICIPANT" },
      take: 4,
      orderBy: {
        scoor: 'desc', // Adjust to your actual score field name
      },
    });

    // Fetch the latest notice
    const latestNotice = await prisma.notices.findFirst({
      orderBy: {
        date: 'desc',
      },
    });

    // Render the EJS template and pass both variables
    res.render('dashboard', { latestNotice, topPlayers });
  } 
  catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/dashboard/users', async (req, res) => {
  try {
    const users = await prisma.user.findMany({
      orderBy: {
        createdAt: 'asc',
      },
    });
    res.render("users-manager/users", { users });
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
  
});

//search user by id or username or email
app.get('/dashboard/search-user', async  (req, res) => {
  const query = req.query.q;

  let users = [];
  if (query) {
        const user = await prisma.user.findFirst({
          where: { 
            OR: [
              {
                id: isNaN(query) ? undefined : parseInt(query, 10)
              },
              {
                username: query
              },
              {
                email: query
              }
            ]
          }
      });
      if (user) {
          users.push(user);
      }
  } 
  res.render('users-manager/searchuser', { users });
});

app.get('/dashboard/question-manager', async  (req, res) => {
  try {
      res.render("users-manager/question-manager");
  } catch (error) {
      res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.get('/api/questions/', async (req, res) => {
  try {
    const questions = await prisma.questionTest.findMany();
    res.json(questions);
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

//fetch 25 question :
// Fetch all questions
app.get('/api/fetchquestion', async (req, res) => {
  try {
      const questions = await prisma.questionTest.findMany({
        take: 25
      });
      res.status(200).json(questions);
  } catch (error) {
      res.status(500).json({ error: 'Failed to fetch questions' });
  }
});

//update scoor : 
app.post('/api/updatescore', async (req, res) => {
  const { username, newScore } = req.body;

  try {
    const updatedUser = await prisma.user.update({
      where: { username: username },
      data: {
        scoor: {
          increment: newScore
        }
      },
    });

      res.status(200).json(updatedUser);
  } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Failed to update score' });
  }
});

//get scoe live time : 
app.get('/get-score/:username', async (req, res) => {
  const { username } = req.params;

  try {
      const user = await prisma.user.findUnique({
          where: { username: username },
          select: { scoor: true },
      });

      if (!user) {
          return res.status(404).json({ error: 'User not found' });
      }

      res.status(200).json({ scoor: user.scoor });
  } catch (error) {
      console.error('Error fetching score:', error);
      res.status(500).json({ error: 'Failed to fetch score' });
  }
});


app.get('/dashboard/Notices', async (req, res) => {
  try {
    const notices = await prisma.notices.findMany({
      orderBy: {
        date: 'desc',
      },
    });
    res.render("users-manager/Notices", { notices });
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});


//routes games :
app.get('/CustomCaptcha', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', '/games/CustomCaptcha/index.html'));
});

app.get('/RockPaperScissors', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', '/games/RockPaperScissors/index.html'));
});

app.get('/TicTacToe', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', '/games/TicTacToe/index.html'));
});

app.get('/TypingSpeed', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', '/games/TypingSpeedGame/index.html'));
});

app.get('/WordScramble', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', '/games/WordScrambleGame/index.html'));
});

app.get('/Quiz', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', '/games/Quiz/index.html'));
});
//end routes


app.get('/questionner', (req, res) => {
  res.render("questionner.ejs");
});


app.use(express.static('public'));

// Middleware de gestion des erreurs
app.use(errorHandler);

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
