const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

// const login = async (req, res, next) => {
//   try {
//     const { email, password } = req.body;
//     const user = await prisma.user.findUnique({ where: { email } });
//     if (!user) {
//       return res.status(401).json({ error: 'Invalid email or password' });
//     }
//     const isValidPassword = await bcrypt.compare(password, user.password);

//     if (!isValidPassword) {
//       return res.status(401).json({ error: 'Invalid email or password!' });
//     }

//     const token = jwt.sign({ userId: user.id, role: user.role, username : user.username},
//                             process.env.JWT_SECRET,
//                             { expiresIn: '1h' }
//     );

//     //decode tocken
//       // const decoded = jwt.verify(token, process.env.JWT_SECRET);
//       // console.log("test decode : ",decoded);


//      // Set token as HttpOnly cookie
//     // res.cookie('token', token, {
//     //   httpOnly: true,
//     //   secure: true, // Set to true if using HTTPS
//     //   sameSite: 'Strict', // CSRF protection
//     // });

//     // Instead of just sending a JSON response, send a success status and the redirect URL
//     res.status(200).json({ 
//       success: true, 
//       token: token,
//       username: user.username,
//       redirectUrl: '/dashboard' // or whatever page you want to redirect to
//     });
//     // res.redirect('/dashboard');


//     // res.json({ token });
//   } catch (error) {
//     next(error);
//   }
// };

const authenticateToken = (req, res, next) => {
  const token = req.cookies.token; // Assuming you're storing the token in cookies

  if (!token) {
    return res.redirect('/login'); // Redirect to login if no token is found
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next(); // Proceed to the next middleware/route handler
  } catch (err) {
    return res.redirect('/login'); // Redirect to login if the token is invalid
  }
};



const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    const isValidPassword = await bcrypt.compare(password, user.password);

    if (!isValidPassword) {
      return res.status(401).json({ error: 'Invalid email or password!' });
    }

    const token = jwt.sign(
      { userId: user.id, role: user.role, username: user.username },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    // Set token as HttpOnly cookie
    // res.cookie('token', token, {
    //   httpOnly: true,
    //   secure: true, // Set to true if using HTTPS
    //   sameSite: 'Strict', // CSRF protection
    // });

    // console.log("send info to local", user.username,user.role, user.scoor);

    // Send success status and redirect URL
    res.status(200).json({
      success: true,
      iduser: user.id,
      username: user.username,
      role: user.role,
      score: user.scoor,
      redirectUrl: '/dashboard' // or whatever page you want to redirect to
    });

  } catch (error) {
    next(error);
  }
};




// const register = async (req, res, next) => {
//   try {
//     const { username, email, password, role } = req.body;
//     const hashedPassword = await bcrypt.hash(password, 10);

//     const newUser = await prisma.user.create({
//       data: {
//         username,
//         email,
//         password: hashedPassword,
//         role,
//       },
//     });

//     res.status(201).json(newUser);
//   } catch (error) {
//     next(error);
//   }
// };

const register = async (req, res, next) => {
  try {
    const { username, email, password} = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const role_user = "PARTICIPANT";

    const newUser = await prisma.user.create({
      data: {
        username,
        email,
        //password,
        password : hashedPassword,
        role : role_user,
        scoor:0,
      },
    });

    // res.status(201).json(newUser);
    // res.status(200).json({ 
    //   success: true,
    //   username: username,
    //   redirectUrl: '/dashboard' // or whatever page you want to redirect to
    // });
    // console.log(newUser);
    res.redirect('/login');
  } catch (error) {
    next(error);
  }
};


module.exports = {
  authenticateToken,
  login,
  register,
};
