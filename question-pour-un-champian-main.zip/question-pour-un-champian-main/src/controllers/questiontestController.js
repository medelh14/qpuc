const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const fs = require('fs');
const path = require('path');
const ExcelJS = require('exceljs');

const Add = async (req, res, next) => {
    try {
        const { categorie, question, responses1, responses2, responses3, responses4, correctAnswer, Point } = req.body;
        const responses = `${responses1}.${responses2}.${responses3}.${responses4}`;
        const newQuestion = await prisma.questionTest.create({
          data: {
            categorie,
            question,
            correctAnswer,
            responses,
            Point: parseInt(Point),
            createdAt : new Date(),
          },
        });
        // res.status(200).send('Question added successfully!');
        res.redirect('/dashboard/question-manager');
      } catch (error) {
        console.error(error);
        res.status(500).send('An error occurred while adding the question.');
      }
};

const Delete = async (req, res, next) => {
    const { id } = req.params;
    try {
        await prisma.questionTest.delete({
            where: { id: parseInt(id) },
        });
        res.redirect('/dashboard/question-manager');
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

const Update = async (req, res, next) => {
    const { id } = req.params;
    const { categorie, question, responses1, responses2, responses3, responses4, correctAnswer, Point } = req.body;
    const responses = `${responses1}.${responses2}.${responses3}.${responses4}`;
    try {
        await prisma.questionTest.update({
        where: { id: parseInt(id) },
        data: 
        { 
            categorie,
            question,
            correctAnswer,
            responses,
            Point: parseInt(Point),
            updatedAt : new Date(),
         },
        });
        res.redirect('/dashboard/question-manager');
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
    
};


//upload : 

const uploadExcel = async (req, res) => {
    try {
        const filePath = path.join(__dirname, '..', 'uploads', req.file.filename);
        const workbook = new ExcelJS.Workbook();
        await workbook.xlsx.readFile(filePath);

        const worksheet = workbook.getWorksheet(1);
        const questions = [];

        worksheet.eachRow((row, rowNumber) => {
            if (rowNumber > 1) { // Skip header row
                const question = {
                    categorie: String(row.getCell(1).value),
                    question: String(row.getCell(2).value),
                    responses: String(`${row.getCell(3).value}.${row.getCell(4).value}.${row.getCell(5).value}.${row.getCell(6).value}`),
                    correctAnswer: String(row.getCell(7).value),
                    Point: parseInt(row.getCell(8).value),
                    createdAt: new Date(),
                };
                questions.push(question);
            }
        });

        await prisma.questionTest.createMany({ data: questions });
        fs.unlinkSync(filePath); // Clean up the uploaded file

        res.redirect('/dashboard/question-manager');
    } catch (error) {
        console.error(error);
        res.status(500).send('An error occurred while processing the Excel file.');
    }
};

const uploadJson = async (req, res) => {
    try {
        const filePath = path.join(__dirname, '..', 'uploads', req.file.filename);
        const data = fs.readFileSync(filePath, 'utf8');
        const questions = JSON.parse(data);

        const formattedQuestions = questions.map((question) => ({
            categorie: String(question.categorie),
            question: String(question.question),
            responses: question.responses.join('.'), // Convert responses array to string
            correctAnswer: String(question.correctAnswer),
            Point: parseInt(question.Point),
            createdAt: new Date()
          }));

        await prisma.questionTest.createMany({ data: formattedQuestions });
        fs.unlinkSync(filePath); // Clean up the uploaded file

        res.redirect('/dashboard/question-manager');
    } catch (error) {
        console.error(error);
        res.status(500).send('An error occurred while processing the JSON file.');
    }
};


  
module.exports = {
Add,
Delete,
Update,
uploadExcel,
uploadJson,
};