const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const getAllGameSessions = async (req, res, next) => {
  try {
    const gameSessions = await prisma.gameSession.findMany({
      include: {
        admin: true,
        participants: {
          include: {
            user: true,
          },
        },
        questions: {
          include: {
            question: true,
          },
        },
        responses: {
          include: {
            participant: true,
            question: true,
          },
        },
      },
    });
    res.json(gameSessions);
  } catch (error) {
    next(error);
  }
};

const getGameSessionById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const gameSession = await prisma.gameSession.findUnique({
      where: { id: Number(id) },
      include: {
        admin: true,
        participants: {
          include: {
            user: true,
          },
        },
        questions: {
          include: {
            question: true,
          },
        },
        responses: {
          include: {
            participant: true,
            question: true,
          },
        },
      },
    });
    if (!gameSession) {
      const error = new Error('Game session not found');
      error.status = 404;
      throw error;
    }
    res.json(gameSession);
  } catch (error) {
    next(error);
  }
};

const createGameSession = async (req, res, next) => {
  try {
    const { adminId, startTime, status, participantIds, questionIds } = req.body;

    const newGameSession = await prisma.gameSession.create({
      data: {
        adminId,
        startTime,
        status,
        participants: {
          create: participantIds.map((userId) => ({
            userId,
          })),
        },
        questions: {
          create: questionIds.map((questionId) => ({
            questionId,
          })),
        },
      },
      include: {
        admin: true,
        participants: {
          include: {
            user: true,
          },
        },
        questions: {
          include: {
            question: true,
          },
        },
        responses: {
          include: {
            participant: true,
            question: true,
          },
        },
      },
    });
    res.status(201).json(newGameSession);
  } catch (error) {
    next(error);
  }
};

const updateGameSession = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { adminId, startTime, endTime, status, participantIds, questionIds } = req.body;

    const updatedGameSession = await prisma.gameSession.update({
      where: { id: Number(id) },
      data: {
        adminId,
        startTime,
        endTime,
        status,
        participants: {
          deleteMany: {}, // Delete existing participants
          create: participantIds.map((userId) => ({
            userId,
          })),
        },
        questions: {
          deleteMany: {}, // Delete existing questions
          create: questionIds.map((questionId) => ({
            questionId,
          })),
        },
      },
      include: {
        admin: true,
        participants: {
          include: {
            user: true,
          },
        },
        questions: {
          include: {
            question: true,
          },
        },
        responses: {
          include: {
            participant: true,
            question: true,
          },
        },
      },
    });
    res.json(updatedGameSession);
  } catch (error) {
    next(error);
  }
};

const deleteGameSession = async (req, res, next) => {
  try {
    const { id } = req.params;
    await prisma.gameSession.delete({ where: { id: Number(id) } });
    res.status(204).send();
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getAllGameSessions,
  getGameSessionById,
  createGameSession,
  updateGameSession,
  deleteGameSession,
};
