const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const getAllQuestions = async (req, res, next) => {
  try {
    const questions = await prisma.question.findMany({
      include: {
        responses: true,
        gameSessions: true,
      },
    });
    res.json(questions);
  } catch (error) {
    next(error);
  }
};

const getQuestionById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const question = await prisma.question.findUnique({
      where: { id: Number(id) },
      include: {
        responses: true,
        gameSessions: true,
      },
    });
    if (!question) {
      const error = new Error('Question not found');
      error.status = 404;
      throw error;
    }
    res.json(question);
  } catch (error) {
    next(error);
  }
};

const createQuestion = async (req, res, next) => {
  try {
    const newQuestion = await prisma.question.create({
      data: req.body,
      include: {
        responses: true,
        gameSessions: true,
      },
    });
    res.status(201).json(newQuestion);
  } catch (error) {
    next(error);
  }
};

const updateQuestion = async (req, res, next) => {
  try {
    const { id } = req.params;
    const updatedQuestion = await prisma.question.update({
      where: { id: Number(id) },
      data: req.body,
      include: {
        responses: true,
        gameSessions: true,
      },
    });
    res.json(updatedQuestion);
  } catch (error) {
    next(error);
  }
};

const deleteQuestion = async (req, res, next) => {
  try {
    const { id } = req.params;
    await prisma.question.delete({ where: { id: Number(id) } });
    res.status(204).send();
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getAllQuestions,
  getQuestionById,
  createQuestion,
  updateQuestion,
  deleteQuestion,
};
