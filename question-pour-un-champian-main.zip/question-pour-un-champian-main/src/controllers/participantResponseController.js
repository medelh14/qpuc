const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const getAllResponses = async (req, res, next) => {
  try {
    const responses = await prisma.participantResponse.findMany({
      include: {
        session: true,
        participant: true,
        question: true,
      },
    });
    res.json(responses);
  } catch (error) {
    next(error);
  }
};

const getResponseById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const response = await prisma.participantResponse.findUnique({
      where: { id: Number(id) },
      include: {
        session: true,
        participant: true,
        question: true,
      },
    });
    if (!response) {
      const error = new Error('Response not found');
      error.status = 404;
      throw error;
    }
    res.json(response);
  } catch (error) {
    next(error);
  }
};

const createResponse = async (req, res, next) => {
  try {
    const newResponse = await prisma.participantResponse.create({
      data: req.body,
      include: {
        session: true,
        participant: true,
        question: true,
      },
    });
    res.status(201).json(newResponse);
  } catch (error) {
    next(error);
  }
};

const updateResponse = async (req, res, next) => {
  try {
    const { id } = req.params;
    const updatedResponse = await prisma.participantResponse.update({
      where: { id: Number(id) },
      data: req.body,
      include: {
        session: true,
        participant: true,
        question: true,
      },
    });
    res.json(updatedResponse);
  } catch (error) {
    next(error);
  }
};

const deleteResponse = async (req, res, next) => {
  try {
    const { id } = req.params;
    await prisma.participantResponse.delete({ where: { id: Number(id) } });
    res.status(204).send();
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getAllResponses,
  getResponseById,
  createResponse,
  updateResponse,
  deleteResponse,
};
