const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const Add = async (req, res, next) => {

    const { comment } = req.body;
    try {
        const newNotice = await prisma.notices.create({
        data: {
            comment,
            date: new Date(), // Automatically set the current date and time
        },
        });
        res.redirect('/dashboard/notices');
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};

const Delete = async (req, res, next) => {
    const { id } = req.params;
    try {
        await prisma.notices.delete({
        where: { id: parseInt(id) },
        });
        res.redirect('/dashboard/notices');
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};

const Update = async (req, res, next) => {
    const { id } = req.params;
    const { comment } = req.body;
    try {
        await prisma.notices.update({
        where: { id: parseInt(id) },
        data: 
        { comment,
            date: new Date(),
         },
        });
        res.redirect('/dashboard/notices');
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
};
  
  
module.exports = {
Add,
Delete,
Update,
};