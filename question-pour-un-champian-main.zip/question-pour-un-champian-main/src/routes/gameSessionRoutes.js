const express = require('express');
const gameSessionController = require('../controllers/gameSessionController');

const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: GameSessions
 *   description: Game session management routes
 */

/**
 * @swagger
 * /gamesessions:
 *   get:
 *     summary: Get all game sessions
 *     tags: [GameSessions]
 *     responses:
 *       200:
 *         description: List of all game sessions
 */
router.get('/', gameSessionController.getAllGameSessions);

/**
 * @swagger
 * /gamesessions/{id}:
 *   get:
 *     summary: Get game session by ID
 *     tags: [GameSessions]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Game session data
 */
router.get('/:id', gameSessionController.getGameSessionById);

/**
 * @swagger
 * /gamesessions:
 *   post:
 *     summary: Create a new game session
 *     tags: [GameSessions]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - moderatorId
 *               - startTime
 *               - status
 *             properties:
 *               moderatorId:
 *                 type: integer
 *               startTime:
 *                 type: string
 *                 format: date-time
 *               endTime:
 *                 type: string
 *                 format: date-time
 *               status:
 *                 type: string
 *               questions:
 *                 type: array
 *                 items:
 *                   type: object
 *                   properties:
 *                     questionId:
 *                       type: integer
 *     responses:
 *       201:
 *         description: Game session created
 */
router.post('/', gameSessionController.createGameSession);

/**
 * @swagger
 * /gamesessions/{id}:
 *   put:
 *     summary: Update game session by ID
 *     tags: [GameSessions]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               moderatorId:
 *                 type: integer
 *               startTime:
 *                 type: string
 *                 format: date-time
 *               endTime:
 *                 type: string
 *                 format: date-time
 *               status:
 *                 type: string
 *               questions:
 *                 type: array
 *                 items:
 *                   type: object
 *                   properties:
 *                     questionId:
 *                       type: integer
 *     responses:
 *       200:
 *         description: Game session updated
 */
router.put('/:id', gameSessionController.updateGameSession);

/**
 * @swagger
 * /gamesessions/{id}:
 *   delete:
 *     summary: Delete game session by ID
 *     tags: [GameSessions]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       204:
 *         description: Game session deleted
 */
router.delete('/:id', gameSessionController.deleteGameSession);

module.exports = router;
