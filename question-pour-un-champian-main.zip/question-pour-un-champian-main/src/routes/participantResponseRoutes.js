const express = require('express');
const participantResponseController = require('../controllers/participantResponseController');

const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: ParticipantResponses
 *   description: Participant response management routes
 */

/**
 * @swagger
 * /responses:
 *   get:
 *     summary: Get all participant responses
 *     tags: [ParticipantResponses]
 *     responses:
 *       200:
 *         description: List of all participant responses
 */
router.get('/', participantResponseController.getAllResponses);

/**
 * @swagger
 * /responses/{id}:
 *   get:
 *     summary: Get participant response by ID
 *     tags: [ParticipantResponses]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Participant response data
 */
router.get('/:id', participantResponseController.getResponseById);

/**
 * @swagger
 * /responses:
 *   post:
 *     summary: Create a new participant response
 *     tags: [ParticipantResponses]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - sessionId
 *               - participantId
 *               - questionId
 *               - response
 *               - isCorrect
 *             properties:
 *               sessionId:
 *                 type: integer
 *               participantId:
 *                 type: integer
 *               questionId:
 *                 type: integer
 *               response:
 *                 type: string
 *               isCorrect:
 *                 type: boolean
 *     responses:
 *       201:
 *         description: Participant response created
 */
router.post('/', participantResponseController.createResponse);

/**
 * @swagger
 * /responses/{id}:
 *   put:
 *     summary: Update participant response by ID
 *     tags: [ParticipantResponses]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               sessionId:
 *                 type: integer
 *               participantId:
 *                 type: integer
 *               questionId:
 *                 type: integer
 *               response:
 *                 type: string
 *               isCorrect:
 *                 type: boolean
 *     responses:
 *       200:
 *         description: Participant response updated
 */
router.put('/:id', participantResponseController.updateResponse);

/**
 * @swagger
 * /responses/{id}:
 *   delete:
 *     summary: Delete participant response by ID
 *     tags: [ParticipantResponses]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       204:
 *         description: Participant response deleted
 */
router.delete('/:id', participantResponseController.deleteResponse);

module.exports = router;
