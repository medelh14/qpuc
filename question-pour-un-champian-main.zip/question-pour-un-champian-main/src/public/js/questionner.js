// const questions = [
//     {
//         question: "How many days makes a week ?",
//         optionA: "10 days",
//         optionB: "14 days",
//         optionC: "5 days",
//         optionD: "7 days",
//         correctOption: "optionD"
//     },

//     {
//         question: "How many players are allowed on a soccer pitch ?",
//         optionA: "10 players",
//         optionB: "11 players",
//         optionC: "9 players",
//         optionD: "12 players",
//         correctOption: "optionB"
//     },

//     {
//         question: "Who was the first President of USA ?",
//         optionA: "Donald Trump",
//         optionB: "Barack Obama",
//         optionC: "Abraham Lincoln",
//         optionD: "George Washington",
//         correctOption: "optionD"
//     },

//     {
//         question: "30 days has ______ ?",
//         optionA: "January",
//         optionB: "December",
//         optionC: "June",
//         optionD: "August",
//         correctOption: "optionC"
//     },

//     {
//         question: "How manay hours can be found in a day ?",
//         optionA: "30 hours",
//         optionB: "38 hours",
//         optionC: "48 hours",
//         optionD: "24 hours",
//         correctOption: "optionD"
//     },

//     {
//         question: "Which is the longest river in the world ?",
//         optionA: "River Nile",
//         optionB: "Long River",
//         optionC: "River Niger",
//         optionD: "Lake Chad",
//         correctOption: "optionA"
//     },

//     {
//         question: "_____ is the hottest Continent on Earth ?",
//         optionA: "Oceania",
//         optionB: "Antarctica",
//         optionC: "Africa",
//         optionD: "North America",
//         correctOption: "optionC"
//     },

//     {
//         question: "Which country is the largest in the world ?",
//         optionA: "Russia",
//         optionB: "Canada",
//         optionC: "Africa",
//         optionD: "Egypt",
//         correctOption: "optionA"
//     },

//     {
//         question: "Which of these numbers is an odd number ?",
//         optionA: "Ten",
//         optionB: "Twelve",
//         optionC: "Eight",
//         optionD: "Eleven",
//         correctOption: "optionD"
//     },

//     {
//         question: `"You Can't see me" is a popular saying by`,
//         optionA: "Eminem",
//         optionB: "Bill Gates",
//         optionC: "Chris Brown",
//         optionD: "John Cena",
//         correctOption: "optionD"
//     },

//     {
//         question: "Where is the world tallest building located ?",
//         optionA: "Africa",
//         optionB: "California",
//         optionC: "Dubai",
//         optionD: "Italy",
//         correctOption: "optionC"
//     },

//     {
//         question: "The longest river in the United Kingdom is ?",
//         optionA: "River Severn",
//         optionB: "River Mersey",
//         optionC: "River Trent",
//         optionD: "River Tweed",
//         correctOption: "optionA"
//     },


//     {
//         question: "How many permanent teeth does a dog have ?",
//         optionA: "38",
//         optionB: "42",
//         optionC: "40",
//         optionD: "36",
//         correctOption: "optionB"
//     },

//     {
//         question: "Which national team won the football World cup in 2018 ?",
//         optionA: "England",
//         optionB: "Brazil",
//         optionC: "Germany",
//         optionD: "France",
//         correctOption: "optionD"
//     },

//     {
//         question: "Which US state was Donald Trump Born ?",
//         optionA: "New York",
//         optionB: "California",
//         optionC: "New Jersey",
//         optionD: "Los Angeles",
//         correctOption: "optionA"
//     },

//     {
//         question: "How man states does Nigeria have ?",
//         optionA: "24",
//         optionB: "30",
//         optionC: "36",
//         optionD: "37",
//         correctOption: "optionC"
//     },

//     {
//         question: "____ is the capital of Nigeria ?",
//         optionA: "Abuja",
//         optionB: "Lagos",
//         optionC: "Calabar",
//         optionD: "Kano",
//         correctOption: "optionA"
//     },

//     {
//         question: "Los Angeles is also known as ?",
//         optionA: "Angels City",
//         optionB: "Shining city",
//         optionC: "City of Angels",
//         optionD: "Lost Angels",
//         correctOption: "optionC"
//     },

//     {
//         question: "What is the capital of Germany ?",
//         optionA: "Georgia",
//         optionB: "Missouri",
//         optionC: "Oklahoma",
//         optionD: "Berlin",
//         correctOption: "optionD"
//     },

//     {
//         question: "How many sides does an hexagon have ?",
//         optionA: "Six",
//         optionB: "Sevene",
//         optionC: "Four",
//         optionD: "Five",
//         correctOption: "optionA"
//     },

//     {
//         question: "How many planets are currently in the solar system ?",
//         optionA: "Eleven",
//         optionB: "Seven",
//         optionC: "Nine",
//         optionD: "Eight",
//         correctOption: "optionD"
//     },

//     {
//         question: "Which Planet is the hottest ?",
//         optionA: "Jupitar",
//         optionB: "Mercury",
//         optionC: "Earth",
//         optionD: "Venus",
//         correctOption: "optionB"
//     },

//     {
//         question: "where is the smallest bone in human body located?",
//         optionA: "Toes",
//         optionB: "Ears",
//         optionC: "Fingers",
//         optionD: "Nose",
//         correctOption: "optionB"
//     },

//     {
//         question: "How many hearts does an Octopus have ?",
//         optionA: "One",
//         optionB: "Two",
//         optionC: "Three",
//         optionD: "Four",
//         correctOption: "optionC"
//     },

//     {
//         question: "How many teeth does an adult human have ?",
//         optionA: "28",
//         optionB: "30",
//         optionC: "32",
//         optionD: "36",
//         correctOption: "optionC"
//     }

// ]


// let shuffledQuestions = [] //empty array to hold shuffled selected questions out of all available questions

// function handleQuestions() { 
//     //function to shuffle and push 10 questions to shuffledQuestions array
// //app would be dealing with 10questions per session
//     while (shuffledQuestions.length <= 9) {
//         const random = questions[Math.floor(Math.random() * questions.length)]
//         if (!shuffledQuestions.includes(random)) {
//             shuffledQuestions.push(random)
//         }
//     }
// }


// let questionNumber = 1 //holds the current question number
// let playerScore = 0  //holds the player score
// let wrongAttempt = 0 //amount of wrong answers picked by player
// let indexNumber = 0 //will be used in displaying next question

// // function for displaying next question in the array to dom
// //also handles displaying players and quiz information to dom
// function NextQuestion(index) {
//     handleQuestions()
//     const currentQuestion = shuffledQuestions[index]
//     document.getElementById("question-number").innerHTML = questionNumber
//     document.getElementById("player-score").innerHTML = playerScore
//     document.getElementById("display-question").innerHTML = currentQuestion.question;
//     document.getElementById("option-one-label").innerHTML = currentQuestion.optionA;
//     document.getElementById("option-two-label").innerHTML = currentQuestion.optionB;
//     document.getElementById("option-three-label").innerHTML = currentQuestion.optionC;
//     document.getElementById("option-four-label").innerHTML = currentQuestion.optionD;

// }


// function checkForAnswer() {
//     const currentQuestion = shuffledQuestions[indexNumber] //gets current Question 
//     const currentQuestionAnswer = currentQuestion.correctOption //gets current Question's answer
//     const options = document.getElementsByName("option"); //gets all elements in dom with name of 'option' (in this the radio inputs)
//     let correctOption = null

//     options.forEach((option) => {
//         if (option.value === currentQuestionAnswer) {
//             //get's correct's radio input with correct answer
//             correctOption = option.labels[0].id
//         }
//     })

//     //checking to make sure a radio input has been checked or an option being chosen
//     if (options[0].checked === false && options[1].checked === false && options[2].checked === false && options[3].checked == false) {
//         document.getElementById('option-modal').style.display = "flex"
//     }

//     //checking if checked radio button is same as answer
//     options.forEach((option) => {
//         if (option.checked === true && option.value === currentQuestionAnswer) {
//             document.getElementById(correctOption).style.backgroundColor = "green"
//             playerScore++ //adding to player's score
//             indexNumber++ //adding 1 to index so has to display next question..
//             //set to delay question number till when next question loads
//             setTimeout(() => {
//                 questionNumber++
//             }, 1000)
//         }

//         else if (option.checked && option.value !== currentQuestionAnswer) {
//             const wrongLabelId = option.labels[0].id
//             document.getElementById(wrongLabelId).style.backgroundColor = "red"
//             document.getElementById(correctOption).style.backgroundColor = "green"
//             wrongAttempt++ //adds 1 to wrong attempts 
//             indexNumber++
//             //set to delay question number till when next question loads
//             setTimeout(() => {
//                 questionNumber++
//             }, 1000)
//         }
//     })
// }



// //called when the next button is called
// function handleNextQuestion() {
//     checkForAnswer() //check if player picked right or wrong option
//     unCheckRadioButtons()
//     //delays next question displaying for a second just for some effects so questions don't rush in on player
//     setTimeout(() => {
//         if (indexNumber <= 9) {
// //displays next question as long as index number isn't greater than 9, remember index number starts from 0, so index 9 is question 10
//             NextQuestion(indexNumber)
//         }
//         else {
//             handleEndGame()//ends game if index number greater than 9 meaning we're already at the 10th question
//         }
//         resetOptionBackground()
//     }, 1000);
// }

// //sets options background back to null after display the right/wrong colors
// function resetOptionBackground() {
//     const options = document.getElementsByName("option");
//     options.forEach((option) => {
//         document.getElementById(option.labels[0].id).style.backgroundColor = ""
//     })
// }

// // unchecking all radio buttons for next question(can be done with map or foreach loop also)
// function unCheckRadioButtons() {
//     const options = document.getElementsByName("option");
//     for (let i = 0; i < options.length; i++) {
//         options[i].checked = false;
//     }
// }

// // function for when all questions being answered
// function handleEndGame() {
//     let remark = null
//     let remarkColor = null

//     // condition check for player remark and remark color
//     if (playerScore <= 3) {
//         remark = "Bad Grades, Keep Practicing."
//         remarkColor = "red"
//     }
//     else if (playerScore >= 4 && playerScore < 7) {
//         remark = "Average Grades, You can do better."
//         remarkColor = "orange"
//     }
//     else if (playerScore >= 7) {
//         remark = "Excellent, Keep the good work going."
//         remarkColor = "green"
//     }
//     const playerGrade = (playerScore / 10) * 100

//     //data to display to score board
//     document.getElementById('remarks').innerHTML = remark
//     document.getElementById('remarks').style.color = remarkColor
//     document.getElementById('grade-percentage').innerHTML = playerGrade
//     document.getElementById('wrong-answers').innerHTML = wrongAttempt
//     document.getElementById('right-answers').innerHTML = playerScore
//     document.getElementById('score-modal').style.display = "flex"

// }

// //closes score modal, resets game and reshuffles questions
// function closeScoreModal() {
//     questionNumber = 1
//     playerScore = 0
//     wrongAttempt = 0
//     indexNumber = 0
//     shuffledQuestions = []
//     NextQuestion(indexNumber)
//     document.getElementById('score-modal').style.display = "none"
// }

// //function to close warning modal
// function closeOptionModal() {
//     document.getElementById('option-modal').style.display = "none"
// }




// ?working vertion code ""

// let questions = [];
//         let shuffledQuestions = [];
//         let questionNumber = 1;
//         let playerScore = 0;
//         let wrongAttempt = 0;
//         let indexNumber = 0;

//         // Fetch questions from the server
//         async function fetchQuestions() {
//             try {
//                 const response = await fetch('/api/fetchquestion');
//                 const data = await response.json();
//                 questions = data.map(q => ({
//                     question: q.question,
//                     optionA: q.responses.split('.')[0],
//                     optionB: q.responses.split('.')[1],
//                     optionC: q.responses.split('.')[2],
//                     optionD: q.responses.split('.')[3],
//                     correctOption: q.correctAnswer
//                 }));
//                 handleQuestions(); // Shuffle and select questions after fetching
//                 NextQuestion(0); // Start the quiz after fetching questions
//             } catch (error) {
//                 console.error('Failed to fetch questions:', error);
//             }
//         }

//         // Shuffle and select 10 questions from the fetched questions
//         function handleQuestions() {
//             while (shuffledQuestions.length < 10 && questions.length) {
//                 const randomIndex = Math.floor(Math.random() * questions.length);
//                 const selectedQuestion = questions.splice(randomIndex, 1)[0];
//                 shuffledQuestions.push(selectedQuestion);
//             }
//         }

//         // Display the next question
//         function NextQuestion(index) {
//             const currentQuestion = shuffledQuestions[index];
//             document.getElementById("question-number").innerHTML = questionNumber;
//             document.getElementById("player-score").innerHTML = playerScore;
//             document.getElementById("display-question").innerHTML = currentQuestion.question;
//             document.getElementById("option-one-label").innerHTML = currentQuestion.optionA;
//             document.getElementById("option-two-label").innerHTML = currentQuestion.optionB;
//             document.getElementById("option-three-label").innerHTML = currentQuestion.optionC;
//             document.getElementById("option-four-label").innerHTML = currentQuestion.optionD;
//         }

//         // Check the selected answer
//         function checkForAnswer() {
//             const currentQuestion = shuffledQuestions[indexNumber];
//             const currentQuestionAnswer = currentQuestion.correctOption;
//             const options = document.getElementsByName("option");
//             let correctOption = null;

//             options.forEach((option) => {
//                 if (option.value === currentQuestionAnswer) {
//                     correctOption = option.labels[0].id;
//                 }
//             });

//             if (![...options].some(option => option.checked)) {
//                 document.getElementById('option-modal').style.display = "flex";
//                 return false;
//             }

//             options.forEach((option) => {
//                 if (option.checked) {
//                     const labelId = option.labels[0].id;
//                     if (option.value === currentQuestionAnswer) {
//                         document.getElementById(labelId).style.backgroundColor = "green";
//                         playerScore++;
//                     } else {
//                         document.getElementById(labelId).style.backgroundColor = "red";
//                         document.getElementById(correctOption).style.backgroundColor = "green";
//                         wrongAttempt++;
//                     }
//                     indexNumber++;
//                     return true;
//                 }
//             });
//             return false;
//         }

//         // Handle the next question button click
//         function handleNextQuestion() {
//             const answered = checkForAnswer(); // Check if player picked the right or wrong option
//             if (answered) {
//                 unCheckRadioButtons();
//                 setTimeout(() => {
//                     resetOptionBackground();
//                     if (indexNumber < shuffledQuestions.length) {
//                         NextQuestion(indexNumber);
//                     } else {
//                         handleEndGame();
//                     }
//                 }, 1000);
//             }
//         }

//         // Reset the background color of options
//         function resetOptionBackground() {
//             const options = document.getElementsByName("option");
//             options.forEach((option) => {
//                 document.getElementById(option.labels[0].id).style.backgroundColor = "";
//             });
//         }

//         // Uncheck all radio buttons
//         function unCheckRadioButtons() {
//             const options = document.getElementsByName("option");
//             options.forEach(option => option.checked = false);
//         }

//         // Handle the end of the game
//         function handleEndGame() {
//             let remark = "";
//             let remarkColor = "";

//             if (playerScore <= 3) {
//                 remark = "Bad Grades, Keep Practicing.";
//                 remarkColor = "red";
//             } else if (playerScore >= 4 && playerScore < 7) {
//                 remark = "Average Grades, You can do better.";
//                 remarkColor = "orange";
//             } else if (playerScore >= 7) {
//                 remark = "Excellent, Keep the good work going.";
//                 remarkColor = "green";
//             }

//             const playerGrade = (playerScore / 10) * 100;
//             document.getElementById('remarks').innerHTML = remark;
//             document.getElementById('remarks').style.color = remarkColor;
//             document.getElementById('grade-percentage').innerHTML = playerGrade;
//             document.getElementById('wrong-answers').innerHTML = wrongAttempt;
//             document.getElementById('right-answers').innerHTML = playerScore;
//             document.getElementById('score-modal').style.display = "flex";
//         }

//         // Close score modal and reset the game
//         function closeScoreModal() {
//             questionNumber = 1;
//             playerScore = 0;
//             wrongAttempt = 0;
//             indexNumber = 0;
//             shuffledQuestions = [];
//             fetchQuestions(); // Fetch new questions for the next game
//             document.getElementById('score-modal').style.display = "none";
//         }

//         // Close option modal
//         function closeOptionModal() {
//             document.getElementById('option-modal').style.display = "none";
//         }

//         // Load questions when the page loads
//         document.addEventListener('DOMContentLoaded', fetchQuestions);






//////////////////////////////////
//! v2

// let questions = [];
// let shuffledQuestions = [];
// let currentQuestionIndex = 0;
// let playerScore = 0;
// let wrongAttempt = 0;
// let totalQuestions = 10;


// // Fetch questions from the server
// async function fetchQuestions() {

//     try {
//         const response = await fetch('/api/fetchquestion');
//         const data = await response.json();
//         questions = data.map(q => ({
//             question: q.question,
//             optionA: q.responses.split('.')[0],
//             optionB: q.responses.split('.')[1],
//             optionC: q.responses.split('.')[2],
//             optionD: q.responses.split('.')[3],
//             correctOption: q.correctAnswer
//         }));
//         shuffleAndSelectQuestions(); // Shuffle and select questions after fetching
//         displayQuestion(); // Start the quiz after fetching questions
//     } catch (error) {
//         console.error('Failed to fetch questions:', error);
//     }
// }

// // Shuffle and select 10 questions from the fetched questions
// function shuffleAndSelectQuestions() {
//     shuffledQuestions = questions.sort(() => Math.random() - 0.5).slice(0, totalQuestions);
// }

// // Display the current question
// function displayQuestion() {
//     if (currentQuestionIndex < shuffledQuestions.length) {
//         const currentQuestion = shuffledQuestions[currentQuestionIndex];
//         document.getElementById("question-number").innerHTML = currentQuestionIndex + 1;
//         document.getElementById("total-questions").innerHTML = totalQuestions;
//         document.getElementById("player-score").innerHTML = playerScore;
//         document.getElementById("display-question").innerHTML = currentQuestion.question;
//         document.getElementById("option-one-label").innerHTML = currentQuestion.optionA;
//         document.getElementById("option-two-label").innerHTML = currentQuestion.optionB;
//         document.getElementById("option-three-label").innerHTML = currentQuestion.optionC;
//         document.getElementById("option-four-label").innerHTML = currentQuestion.optionD;
//     } else {
//         handleEndGame();
//     }
// }

// // Check the selected answer
// function checkForAnswer() {
//     const currentQuestion = shuffledQuestions[currentQuestionIndex];
//     const currentQuestionAnswer = currentQuestion.correctOption;
//     const selectedOption = document.querySelector('input[name="option"]:checked');

//     if (!selectedOption) {
//         document.getElementById('option-modal').style.display = "flex";
//         return false;
//     }

//     const selectedOptionValue = selectedOption.value;
//     const selectedOptionLabel = selectedOption.labels[0];

//     // Reset the background color of all options
//     resetOptionBackground();

//     if (selectedOptionValue === currentQuestionAnswer) {
//         selectedOptionLabel.style.backgroundColor = "green";
//         playerScore++;
//     } else {
//         selectedOptionLabel.style.backgroundColor = "red";
//         const correctOptionLabel = document.getElementById(`option-${currentQuestionAnswer.charAt(6)}-label`);
//         if (correctOptionLabel) {
//             correctOptionLabel.style.backgroundColor = "green";
//         }
//         wrongAttempt++;
//     }

//     currentQuestionIndex++;
//     return true;
// }

// // Handle the next question button click
// function handleNextQuestion() {
//     const answered = checkForAnswer(); // Check if player picked the right or wrong option
//     if (answered) {
//         unCheckRadioButtons();
//         setTimeout(() => {
//             resetOptionBackground();
//             displayQuestion();
//         }, 1000);
//     }
// }

// // Reset the background color of options
// function resetOptionBackground() {
//     const options = document.querySelectorAll(".option");
//     options.forEach((option) => {
//         option.style.backgroundColor = "";
//     });
// }

// // Uncheck all radio buttons
// function unCheckRadioButtons() {
//     const options = document.getElementsByName("option");
//     options.forEach(option => option.checked = false);
// }

// // Handle the end of the game
// function handleEndGame() {
//     let remark = "";
//     let remarkColor = "";

//     if (playerScore <= 3) {
//         remark = "Bad Grades, Keep Practicing.";
//         remarkColor = "red";
//     } else if (playerScore >= 4 && playerScore < 7) {
//         remark = "Average Grades, You can do better.";
//         remarkColor = "orange";
//     } else if (playerScore >= 7) {
//         remark = "Excellent, Keep the good work going.";
//         remarkColor = "green";
//     }

//     const playerGrade = (playerScore / totalQuestions) * 100;
//     document.getElementById('remarks').innerHTML = remark;
//     document.getElementById('remarks').style.color = remarkColor;
//     document.getElementById('grade-percentage').innerHTML = playerGrade.toFixed(2);
//     document.getElementById('wrong-answers').innerHTML = wrongAttempt;
//     document.getElementById('right-answers').innerHTML = playerScore;
//     document.getElementById('total-questions').innerHTML = totalQuestions;
//     document.getElementById('score-modal').style.display = "flex";
// }

// // Close score modal and reset the game
// function closeScoreModal() {
//     currentQuestionIndex = 0;
//     playerScore = 0;
//     wrongAttempt = 0;
//     shuffledQuestions = [];
//     fetchQuestions(); // Fetch new questions for the next game
//     document.getElementById('score-modal').style.display = "none";
// }

// // Close option modal
// function closeOptionModal() {
//     document.getElementById('option-modal').style.display = "none";
// }

// // Load questions when the page loads
// document.addEventListener('DOMContentLoaded', fetchQuestions);