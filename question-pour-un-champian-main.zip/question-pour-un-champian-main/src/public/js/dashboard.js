document.addEventListener('DOMContentLoaded', () => {
    const username = localStorage.getItem('username');
    const role = localStorage.getItem('role');
    const score = localStorage.getItem('score');
    // var iduser = localStorage.getItem('iduser');
    const navbar = document.getElementById('navbarlist');
    const usersection = document.getElementById('usernamesection');
    // console.log(username, iduser);

    // console.log(" : ",username," / ", role, " / ",score);

    if (!username){
        window.location.href = '/login';
    }
    else{

        if (navbar && usersection) {
            if (role === 'PARTICIPANT') {
                //<li><a href="/dashboard">Home</a></li>
                navbar.innerHTML = `
                    <li><a href="#" id="logout" style="color: #ab62ed;padding: 10px;">Logout</a></li>`;
                usersection.innerHTML = `Hi : ${username} - Your Score is : <span id="score-label-live">${score}</span>`;
                
            } else if (role === 'ADMIN') {
                navbar.innerHTML = `
                   
                    <li><a href="/dashboard/users">User Management</a></li>
                    <li><a href="/dashboard/question-manager">Question Management</a></li>
                    <li><a href="/dashboard/Notices">Notices</a></li>
                    <li><a  href="#" id="logout" style="color: #ab62ed;padding: 10px;">Logout</a></li>
                `;
                usersection.innerHTML = `Hi Admin : ${username}`;
            }
             // Add event listener for logout
             document.getElementById('logout').addEventListener('click', () => {
                localStorage.removeItem('username');
                localStorage.removeItem('role');
                localStorage.removeItem('score');
                // localStorage.removeItem('iduser');
                window.location.href = '/login';
            });
        } else {
            console.error('Navbar or user section not found in the DOM');
        }
    }
});

//live time scoor : 
document.addEventListener('DOMContentLoaded', () => {
    const username = localStorage.getItem('username');
    const scoreLabel = document.getElementById('score-label-live');
    if(scoreLabel){
        async function fetchUserScore() {
            try {
                const response = await fetch(`/get-score/${username}`);
                if (!response.ok) {
                    throw new Error('Failed to fetch score');
                }
    
                const data = await response.json();
                scoreLabel.textContent = `${data.scoor}`;
            } catch (error) {
                console.error('Error fetching score:', error);
                scoreLabel.textContent = 'Error fetching score';
            }
        }
        setInterval(fetchUserScore, 5000);
        fetchUserScore();
    }

    
});



const tabsBox = document.querySelector(".tabs-box");

if (tabsBox) {

    const allTabs = tabsBox.querySelectorAll(".tab");
    const arrowIcons = document.querySelectorAll(".icon i");

    let isDragging = false;
    
    const handleIcons = (scrollVal) => {
        let maxScrollableWidth = tabsBox.scrollWidth - tabsBox.clientWidth;
        arrowIcons[0].parentElement.style.display = scrollVal <= 0 ? "none" : "flex";
        arrowIcons[1].parentElement.style.display = maxScrollableWidth - scrollVal <= 1 ? "none" : "flex";
    }
    
    arrowIcons.forEach(icon => {
        icon.addEventListener("click", () => {
            // if clicked icon is left, reduce 350 from tabsBox scrollLeft else add
            let scrollWidth = tabsBox.scrollLeft += icon.id === "left" ? -340 : 340;
            handleIcons(scrollWidth);
        });
    });
    
    allTabs.forEach(tab => {
        tab.addEventListener("click", () => {
            tabsBox.querySelector(".active").classList.remove("active");
            tab.classList.add("active");
        });
    });
    
    const dragging = (e) => {
        if(!isDragging) return;
        tabsBox.classList.add("dragging");
        tabsBox.scrollLeft -= e.movementX;
        handleIcons(tabsBox.scrollLeft)
    }
    
    const dragStop = () => {
        isDragging = false;
        tabsBox.classList.remove("dragging");
    }
    
    tabsBox.addEventListener("mousedown", () => isDragging = true);
    tabsBox.addEventListener("mousemove", dragging);
    document.addEventListener("mouseup", dragStop);

}

