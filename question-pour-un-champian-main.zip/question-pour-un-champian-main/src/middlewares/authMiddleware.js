const jwt = require('jsonwebtoken');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

const authenticateToken = (req, res, next) => {
  const authHeader = req.header('Authorization');
  if (!authHeader) {
    return res.status(401).json({ error: 'Access denied, no token provided' });
  }

  const token = authHeader.replace('Bearer ', '');

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    res.status(400).json({ error: 'Invalid token' });
  }
};

const authorizeRole = (roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Access denied' });
    }
    next();
  };
};

const authorizeSelf = async (req, res, next) => {
  const userId = req.user.userId;
  const { id } = req.params;

  if (req.user.role === 'ADMIN' || userId === parseInt(id, 10)) {
    return next();
  }

  const user = await prisma.user.findUnique({ where: { id: parseInt(id, 10) } });

  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  if (userId !== user.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  next();
};

module.exports = {
  authenticateToken,
  authorizeRole,
  authorizeSelf,
};
