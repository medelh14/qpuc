const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  // Create users
  // const admin = await prisma.user.create({
  //   data: {
  //     username: 'admin',
  //     password: 'adminpassword',
  //     email: 'admin@example.com',
  //     role: 'ADMIN',
  //   },
  // });

  // const participant1 = await prisma.user.create({
  //   data: {
  //     username: 'participant1',
  //     password: 'password1',
  //     email: 'participant1@example.com',
  //     role: 'PARTICIPANT',
  //   },
  // });

  // const participant2 = await prisma.user.create({
  //   data: {
  //     username: 'participant2',
  //     password: 'password2',
  //     email: 'participant2@example.com',
  //     role: 'PARTICIPANT',
  //   },
  // });

  // Create questions
  // const question1 = await prisma.question.create({
  //   data: {
  //     text: 'What is the capital of France?',
  //     correctAnswer: 'Paris',
  //     type: 'multiple_choice',
  //     category: 'geography',
  //   },
  // });

  // const question2 = await prisma.question.create({
  //   data: {
  //     text: 'What is 2 + 2?',
  //     correctAnswer: '4',
  //     type: 'multiple_choice',
  //     category: 'math',
  //   },
  // });

  // Create game session
  // const gameSession = await prisma.gameSession.create({
  //   data: {
  //     adminId: admin.id,
  //     startTime: new Date(),
  //     status: 'active',
  //     participants: {
  //       create: [
  //         { userId: participant1.id },
  //         { userId: participant2.id },
  //       ],
  //     },
  //     questions: {
  //       create: [
  //         { questionId: question1.id },
  //         { questionId: question2.id },
  //       ],
  //     },
  //   },
  // });

  // Create participant responses
  // await prisma.participantResponse.create({
  //   data: {
  //     sessionId: gameSession.id,
  //     participantId: participant1.id,
  //     questionId: question1.id,
  //     response: 'Paris',
  //     isCorrect: true,
  //   },
  // });

  // await prisma.participantResponse.create({
  //   data: {
  //     sessionId: gameSession.id,
  //     participantId: participant2.id,
  //     questionId: question2.id,
  //     response: '4',
  //     isCorrect: true,
  //   },
  // });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
