/*
  Warnings:

  - You are about to drop the column `moderatorId` on the `GameSession` table. All the data in the column will be lost.
  - You are about to drop the column `createdAt` on the `GameSessionQuestion` table. All the data in the column will be lost.
  - You are about to drop the column `updatedAt` on the `GameSessionQuestion` table. All the data in the column will be lost.
  - The values [MODERATOR] on the enum `User_role` will be removed. If these variants are still used in the database, this will fail.

*/
-- DropForeignKey
ALTER TABLE `GameSession` DROP FOREIGN KEY `GameSession_moderatorId_fkey`;

-- AlterTable
ALTER TABLE `GameSession` DROP COLUMN `moderatorId`,
    ADD COLUMN `adminId` INTEGER NULL;

-- AlterTable
ALTER TABLE `GameSessionQuestion` DROP COLUMN `createdAt`,
    DROP COLUMN `updatedAt`;

-- AlterTable
ALTER TABLE `User` MODIFY `role` ENUM('ADMIN', 'PARTICIPANT') NOT NULL;

-- CreateTable
CREATE TABLE `GameSessionParticipant` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `gameSessionId` INTEGER NOT NULL,
    `userId` INTEGER NOT NULL,

    UNIQUE INDEX `GameSessionParticipant_gameSessionId_userId_key`(`gameSessionId`, `userId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `GameSession` ADD CONSTRAINT `GameSession_adminId_fkey` FOREIGN KEY (`adminId`) REFERENCES `User`(`id`) ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `GameSessionParticipant` ADD CONSTRAINT `GameSessionParticipant_gameSessionId_fkey` FOREIGN KEY (`gameSessionId`) REFERENCES `GameSession`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `GameSessionParticipant` ADD CONSTRAINT `GameSessionParticipant_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
